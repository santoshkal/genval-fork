# Security Policy

## Supported Versions


| Version | Supported          |
| ------- | ------------------ |
| 1.x.x   | :white_check_mark: |


## Reporting a Vulnerability

Please report security issues using our [Security Form](https://intelops.ai/opensource-security-reporting-form/)

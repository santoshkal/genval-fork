package main

import (
	"github.com/intelops/genval/cmd"
)

func main() {
	cmd.Execute()
}
